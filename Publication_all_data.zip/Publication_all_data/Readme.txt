ONLINE RESOURCE

Publication:
(Pending)
Submitted the journal "Wetlands" (Springer) 06/04/2016.   

Title:
Disaggregating the Patchwork: 
Probabilistic models as tools to predict wetland presence as a continuous gradient

 Authors:
John Humphreys,    
Dr. James B. Elsner,  
Dr. Thomas H. Jagger,    
AmirSassan Mahjoor  

Corresponding Author:  
John Humphreys  
Submerged Lands & Environmental Resources Coordination  
Florida Department of Environmental Protection  
2600 Blair Stone Road, Tallahassee, Fl 32399  
E-mail: john.humphreys@dep.state.fl.us  
Office: (850) 245 � 8487  
  
Alternate Contact:  
Department of Geography  
Room 323, Bellamy Building  
113 Collegiate Loop    
PO Box 3062190  
Florida State University  
Tallahassee FL 32306-2190  
(850) 644-1706  


Contents:
R-Language Coded Script
Format: R-Studio Markdown File (WetlandPatchwork.rmd).

Raw data called from script.
Numerous vector and raster datasets.
File Folder �WetlandData.zip�.

